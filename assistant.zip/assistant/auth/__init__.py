"""
Authentication utilities for WebSocket connections.
"""
