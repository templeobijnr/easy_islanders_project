import React from 'react';
import FeaturedPane from './FeaturedPane';

const FeaturedPanel = () => {
  return <FeaturedPane />;
};

export default FeaturedPanel;